<!DOCTYPE html>
<html>
<head>
	<title>Search</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
	<form action="employeesaldepartmentsearch.php" method="GET">
		<b>Enter a salary:</b>
		<input type="text" name="salary" />
		<b>Enter a Department:</b>
		<input type="text" name="department" />
		<b>Enter employee ssn:</b>
		<input type="text" name="ssn" />
		<input type="submit" value="Search" />
	</form>	
</body>
</html>